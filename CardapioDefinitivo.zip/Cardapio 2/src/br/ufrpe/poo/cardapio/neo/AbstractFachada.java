/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ufrpe.poo.cardapio.neo;

import javax.swing.JLabel;
import javax.swing.JTable;

/**
 *
 * @author Endryo
 */
public abstract class AbstractFachada {

    public abstract void calcularTotalProdutos(JTable tabela, JLabel label);
}
